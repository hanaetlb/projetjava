package pb;

 abstract public class transaction {
     protected String transactionID;
     protected String clientID;

     public transaction(String transactionID, String clientID) {
         this.transactionID = transactionID;
         this.clientID = clientID;
     }
     public abstract void execute();
     public void showDetails(){
         System.out.println("TransactionID: " + transactionID+ "client ID"+ clientID);
     }
}
