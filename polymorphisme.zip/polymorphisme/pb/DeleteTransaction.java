package pb;

public class DeleteTransaction extends transaction {
    public DeleteTransaction(String transactionID, String clientID) {
        super(transactionID, clientID);
    }
    public void execute(){
        System.out.println("Suppression du client avec ID" + clientID);
    }
}
