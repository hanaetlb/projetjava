package pb;

public class TransactionProcessor {
    public static void processTransaction(transaction t){
        t.execute();
    }
}
