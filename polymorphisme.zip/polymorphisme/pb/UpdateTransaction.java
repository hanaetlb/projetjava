package pb;

public class UpdateTransaction extends transaction {
    public UpdateTransaction(String transactionID, String clientID) {
        super(transactionID, clientID);
    }
    public void execute(){
        System.out.println("Mise à jour des informations du client avec ID: " + clientID);
    }
}
