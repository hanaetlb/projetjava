package pb;
import java.util.ArrayList;

public class TestPolymorphism {
    public static void main(String[] args) {
        ArrayList<transaction> transactions = new ArrayList<>();
        transactions.add(new InsertTransaction("T001", "C001"));
        transactions.add(new UpdateTransaction("T002", "C002"));
        transactions.add(new DeleteTransaction("T003", "C003"));

        for (transaction t : transactions) {
            TransactionProcessor.processTransaction(t);
        }
}}
