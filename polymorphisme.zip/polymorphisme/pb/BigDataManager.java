package pb;
import java.util.ArrayList;
public class BigDataManager {
    private ArrayList<transaction> transactions;
    private int transactions_réussies;
    private int transactions_echoue;

    public BigDataManager() {
        transactions = new ArrayList<>();
    }

    public void Ajoutertransactions(transaction t) {
        transactions.add(t);
    }

    public void traittransaction(transaction t) {

    }
    public void réussiesechoue(){
        System.out.println(" les transactions réussies"+transactions_réussies+" les transactions echoue"+transactions_echoue);
    }
}
