package pb;

public class InsertTransaction extends transaction {
    public InsertTransaction(String transactionID, String clientID) {
        super(transactionID, clientID);
    }
    public void execute(){
        System.out.println("Insert Transaction" + clientID);
    }

}
