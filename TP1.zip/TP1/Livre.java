package Biblio;

public class Livre {
    public String titre;
    public String auteur;
    public int aneePublication;
    public Livre(String titre,String auteur,int aneePublication){
        this.titre=titre;
        this.auteur=auteur;
        this.aneePublication=aneePublication;
    }
    public void afficherDetails(){
        System.out.println("le titre est "+this.titre+" l'auteur est "+this.auteur+" l'anee de publication  est "+this.aneePublication);
    }
}

