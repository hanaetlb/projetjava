package Biblio;

public class Main {
    public static void  main (String[] args){
        Livre L = new Livre("boite a merveille","safrioui",1999);
        L.afficherDetails();
        Bibliotheque B= new Bibliotheque();
        B.ajouterLivre("abcd");
        B.rechercherLivre("safrioui");
        B.afficherLivre();
    }
}
