package Biblio;
import java.util.ArrayList;
public class Bibliotheque {
    public ArrayList <String> ListLivre;
    public Bibliotheque() {
        this.ListLivre = new ArrayList<>();
    }
    public void ajouterLivre(String Livre){
        ListLivre.add(Livre);
    }
    public void rechercherLivre(String auteur){
        if (ListLivre.contains(auteur)){
            System.out.println("les livres de "+ auteur + " est " + ListLivre);
        }
    }
    public void afficherLivre(){
        System.out.println("les livres sont "+this.ListLivre);
    }
}
