package RB;

public class MAIN {
    public static void main(String[] args){
        robot R =new robot("Myrobot");
        R.setY(12);
        R.setX(10);
        R.setDirection("Nord");
        R.avance();
        R.droite();
        R.afficher();
    }
}
