package RB;

public class robot {
    private String nom;
    private int x;
    private int y;
    private String direction;
    public robot(String nom) {
        this.nom = nom;
        this.x = 0;
        this.y = 0;
        this.direction ="est";
    }
    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }
    public void setDirection(String direction) {
        this.direction = direction;
    }
    public void avance(){
        if (direction =="Est") {
            x++;
        }
        if (direction =="Nord") {
            y++;
        }
        if (direction =="Sud") {
            y--;
        }
        if (direction =="Ouest") {
            x--;
        }
    }
    public void droite(){
        if (direction =="Est") {
            direction="Sud";
        }
        if (direction =="Nord") {
            direction="Est";
        }
        if (direction =="Sud") {
            direction="Ouest";
        }
        if (direction =="Ouest") {
            direction="Nord";
        }

    }
    public void afficher(){
        System.out.println("//le nom est: "+nom+ " //la direction est le : "+direction + " //la position est: ("+x+","+y+")");
    }


}
