package VH;

public class Vehicule {
    private int id;
    private String modele;
    private int autonomieBatterie;
    private boolean estDisponible;

    public Vehicule(int id, String modele, int autonomieBatterie) {
        this.id = id;
        this.modele = modele;
        this.autonomieBatterie = autonomieBatterie;
        this.estDisponible = true; // Initialisation par défaut à disponible
    }

    public int getId() {
        return id;
    }

    public String getModele() {
        return modele;
    }

    public int getAutonomieBatterie() {
        return autonomieBatterie;
    }

    public boolean isDisponible() {
        return estDisponible;
    }

    public void setDisponible(boolean estDisponible) {
        this.estDisponible = estDisponible;
    }

    @Override
    public String toString() {
        return "Vehicule{id=" + id + ", modele=" + modele + ", autonomieBatterie=" + autonomieBatterie + ", estDisponible=" + estDisponible + "}";
    }
}

