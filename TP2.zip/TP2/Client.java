package VH;

public class Client {
    private int id;
    private String nom;
    private Vehicule vehiculeLoue;

    public Client(int id, String nom) {
        this.id = id;
        this.nom = nom;
        this.vehiculeLoue = null;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public Vehicule getVehiculeLoue() {
        return vehiculeLoue;
    }

    public boolean louerVehicule(Vehicule vehicule) {
        if (vehicule.isDisponible()) {
            this.vehiculeLoue = vehicule;
            vehicule.setDisponible(false);
            return true;
        } else {
            return false;
        }
    }

    public void retournerVehicule() {
        if (this.vehiculeLoue != null) {
            this.vehiculeLoue.setDisponible(true);
            this.vehiculeLoue = null;
        } else {
            System.out.println("Aucun véhicule à retourner.");
        }
    }

    @Override
    public String toString() {
        return "Client{id=" + id + ", nom=" + nom + ", vehiculeLoue=" + (vehiculeLoue != null ? vehiculeLoue.getModele() : "aucun") + "}";
    }
}
