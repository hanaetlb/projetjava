package VH;

import java.util.ArrayList;

public class GestionParc {
    private ArrayList<Vehicule> vehicules;
    private ArrayList<Client> clients;

    public GestionParc() {
        vehicules = new ArrayList<>();
        clients = new ArrayList<>();
    }

    public void ajouterVehicule(Vehicule vehicule) {
        vehicules.add(vehicule);
    }

    public void ajouterClient(Client client) {
        clients.add(client);
    }

    public void affecterVehiculeAClient(Client client, int vehiculeId) {
        for (Vehicule vehicule : vehicules) {
            if (vehicule.getId() == vehiculeId && vehicule.isDisponible()) {
                client.louerVehicule(vehicule);
                break;
            }
        }
    }

    public void afficherVehiculesDisponibles() {
        System.out.println("Véhicules disponibles :");
        for (Vehicule vehicule : vehicules) {
            if (vehicule.isDisponible()) {
                System.out.println(vehicule);
            }
        }
    }

    public void afficherClients() {
        System.out.println("Clients :");
        for (Client client : clients) {
            System.out.println(client);
        }
    }
}








