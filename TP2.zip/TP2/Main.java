package VH;

public class Main {
    public static void main(String[] args) {
        GestionParc gestionParc = new GestionParc();
        Vehicule v1 = new Vehicule(1, "Tesla Model S", 500);
        Vehicule v2 = new Vehicule(2, "Nissan Leaf", 300);
        Client c1 = new Client(1, "Alice");
        Client c2 = new Client(2, "Bob");

        gestionParc.ajouterVehicule(v1);
        gestionParc.ajouterVehicule(v2);

        gestionParc.ajouterClient(c1);
        gestionParc.ajouterClient(c2);

        gestionParc.affecterVehiculeAClient(c1, 1);
        gestionParc.afficherVehiculesDisponibles();
        gestionParc.afficherClients();

        c1.retournerVehicule();
        gestionParc.afficherVehiculesDisponibles();
        gestionParc.afficherClients();
    }
}
