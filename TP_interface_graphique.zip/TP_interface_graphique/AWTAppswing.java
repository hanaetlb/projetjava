package IG;

import javax.swing.*;
import java.awt.*;

public class AWTAppswing extends JFrame{
    private JLabel label1;
    private JTextField txt1;
    private JButton btn1;
    private JPanel p1;
    public AWTAppswing() {
        this.setLayout(new BorderLayout());
        label1 = new JLabel("code etudiant ");
        txt1 = new JTextField(10);
        btn1 = new JButton("rechercher");
        p1=new JPanel();
        p1.setLayout(new FlowLayout());
        p1.add(label1);
        p1.add(txt1);
        p1.add(btn1);
        this.add(p1, BorderLayout.NORTH);
        this.setBounds(10, 10, 450,350) ;
        this.setVisible(true);
}}
