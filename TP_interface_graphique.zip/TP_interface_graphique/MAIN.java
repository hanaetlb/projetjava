package IG;

public class MAIN {
    public static void main(String[] args) {
        //new AWTApplication();
        //new AWTAppswing();
        new AppliGraphiqueListener();
    }
}
