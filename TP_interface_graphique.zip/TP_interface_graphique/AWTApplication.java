package IG;

import java.awt.*;

public class AWTApplication extends Frame  {
    private Label label1;
    private TextField txt1;
    private Button btn1;
    private Panel p1;
    public AWTApplication() {
        this.setLayout(new BorderLayout());
        label1 = new Label("code etudiant ");
        txt1 = new TextField(10);
        btn1 = new Button("rechercher");
        p1=new Panel();
        p1.setLayout(new FlowLayout());
        p1.add(label1);
        p1.add(txt1);
        p1.add(btn1);

        this.add(p1, BorderLayout.NORTH);
        this.setBounds(10, 10, 450,350) ;
        this.setVisible(true);
    }


}
