package IG;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class AppliGraphiqueListener extends JFrame implements ActionListener {
    private JLabel label1 = new JLabel("Nom");
    private JTextField txt = new JTextField(5);
    private JButton btnOK = new JButton("Ajouter");
    private JButton btnQUITTER = new JButton("Quitter");
    private JPanel jp1 = new JPanel();
    private DefaultListModel<String> listModel = new DefaultListModel<>();
    private JList<String> liste = new JList<>(listModel);
    //2
    private JLabel label2 = new JLabel("prenom");
    private JTextField txt2 = new JTextField(5);
    private JButton btnOK2 = new JButton("Ajouter");
    private JButton btnQUITTER2 = new JButton("Quitter");
    private JPanel jp2 = new JPanel();
    private DefaultListModel<String> listModel2 = new DefaultListModel<>();
    private JList<String> liste2 = new JList<>(listModel2);
    //3
    private JLabel label3 = new JLabel("Module");
    private JTextField txt3 = new JTextField(5);
    private JButton btnOK3 = new JButton("Ajouter");
    private JButton btnQUITTER3 = new JButton("Quitter");
    private JPanel jp3 = new JPanel();
    private DefaultListModel<String> listModel3 = new DefaultListModel<>();
    private JList<String> liste3 = new JList<>(listModel3);

    public AppliGraphiqueListener() {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        //1
        jp1.setLayout(new FlowLayout());
        jp1.add(label1);
        jp1.add(txt);
        jp1.add(btnOK);
        jp1.add(btnQUITTER);
        this.add(jp1, BorderLayout.NORTH);
        this.add(new JScrollPane(liste), BorderLayout.WEST); // Add the list to the west
        btnOK.addActionListener(this);
        btnQUITTER.addActionListener(this);

        //2
        jp2.setLayout(new FlowLayout());
        jp2.add(label2);
        jp2.add(txt2);
        jp2.add(btnOK2);
        jp2.add(btnQUITTER2);
        this.add(jp2, BorderLayout.WEST);
        this.add(new JScrollPane(liste2), BorderLayout.EAST); // Add the list to the east
        btnOK2.addActionListener(this);
        btnQUITTER2.addActionListener(this);

        //3
        jp3.setLayout(new FlowLayout());
        jp3.add(label3);
        jp3.add(txt3);
        jp3.add(btnOK3);
        jp3.add(btnQUITTER3);
        this.add(jp3, BorderLayout.EAST);
        this.add(new JScrollPane(liste3), BorderLayout.SOUTH); // Add the list to the south
        btnOK3.addActionListener(this);
        btnQUITTER3.addActionListener(this);

        this.setBounds(10, 10, 600, 400); // Adjusted size for better layout
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //1
        if (e.getSource() == btnOK) {
            String s = txt.getText();
            if (!s.isEmpty()) {
                listModel.addElement(s);
                txt.setText("");
            }
            if (e.getSource() == btnQUITTER ) {
                System.exit(0);
            }
        }
        //2
        if (e.getSource() == btnOK2) {
            String s = txt2.getText();
            if (!s.isEmpty()) {
                listModel2.addElement(s);
                txt2.setText("");
            }
            if (e.getSource() == btnQUITTER2) {
                System.exit(0);
            }
        }
        //3
        if (e.getSource() == btnOK3) {
            String s = txt3.getText();
            if (!s.isEmpty()) {
                listModel3.addElement(s);
                txt3.setText("");
            }
            if (e.getSource() == btnQUITTER3) {
                System.exit(0);
            }
        }

    }
}
