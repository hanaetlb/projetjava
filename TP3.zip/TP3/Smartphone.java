package SMART;

public class Smartphone extends AppareilElectronique {
    private double tailleEcran;

    public Smartphone(String marque, String modele, double prix, double tailleEcran) {
        super(marque, modele, prix);
        this.tailleEcran = tailleEcran;
    }

    public void afficher() {
        System.out.println("Marque: " + getMarque() + "\nModele: " + getModele() + "\nPrix: " + getPrix() + " la taille d'ecran est " + tailleEcran);
    }
}

