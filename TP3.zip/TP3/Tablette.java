package SMART;

public class Tablette extends AppareilElectronique {
    private int capaciteBatterie;

    public Tablette(String marque, String modele, double prix, int capaciteBatterie) {
        super(marque, modele, prix);
        this.capaciteBatterie = capaciteBatterie;
    }

    public void afficher() {
        System.out.println("Marque: " + getMarque() + "\nModele: " + getModele() + "\nPrix: " + getPrix() + " la capacite est " + capaciteBatterie);
    }
}

