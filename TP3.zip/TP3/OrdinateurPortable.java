package SMART;

public class OrdinateurPortable extends AppareilElectronique {
    private int ram;

    public OrdinateurPortable(String marque, String modele, double prix, int ram) {
        super(marque, modele, prix);
        this.ram = ram;
    }

    public void afficher() {
        System.out.println("Marque: " + getMarque() + "\nModele: " + getModele() + "\nPrix: " + getPrix() + " la ram est " + ram);
    }
}

