package SMART;

import java.util.ArrayList;

public class GestionInventaire {
    ArrayList<AppareilElectronique> inventaire;

    public GestionInventaire() {
        inventaire = new ArrayList<>();
    }

    public void ajouter(AppareilElectronique appareil) {
        inventaire.add(appareil);
    }

    public void afficher() {
        for (AppareilElectronique appareil : inventaire) {
            appareil.afficher();
        }
    }
}
